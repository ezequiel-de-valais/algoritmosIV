/*
 * This file is part of the Mingw32 package.
 *
 * This file.h maps to the root fcntl.h
 * TODO?
 */
#include <fcntl.h>
